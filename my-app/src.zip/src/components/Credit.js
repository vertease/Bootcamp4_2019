import React from 'react';

class Credit extends React.Component {
	render() {
		return (
			<div className="credit">
				<p>
					Source of building list:{' '}
					<a href="http://www.ufl.edu">University of Florida </a>
				</p>
			</div>
		);
	}
}
export default Credit;
