import React from 'react';
import Button from 'react-bootstrap/Button';

class AddBuilding extends React.Component {
    
    add() {
        this.props.addOne()
    }
    
    render(){
        return(
            <Button 
            onClick={this.add.bind(this)}
            variant="info">
                
                Add Building
            
            </Button>
        );
    }

}

export default AddBuilding;