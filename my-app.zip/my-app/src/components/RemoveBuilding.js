import React from 'react';
import Button from 'react-bootstrap/Button';

class RemoveBuilding extends React.Component {
    render(){

        return(
            <Button variant="danger">Remove Building</Button> 
        );
        
    }

}

export default RemoveBuilding;